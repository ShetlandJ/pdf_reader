from PyPDF2 import PdfFileWriter, PdfFileReader

output = PdfFileWriter()
input1 = PdfFileReader(open("home_report.pdf", "rb"))

# print how many pages input1 has:
print("document1.pdf has %d pages." % input1.getNumPages())
